SELECT * FROM sbi_bank.public;

desc public;
----------------------------------------------------------------------------------------------------------------------------
##---1..Year-wise Loan Amount Stats
SELECT 
    `issue_d - year` AS loan_year,
    SUM(loan_amnt) AS total_loan_amount
FROM public
GROUP BY `issue_d - year`
ORDER BY loan_year;


-----------------------------------------------------------------------------------------------------------------------------
##..2... Grade & Sub-grade Wise Revolving Balance

SELECT 
    grade,
    sub_grade,
    SUM(loan_amnt) AS total_loan_amount
FROM public
GROUP BY grade, sub_grade
ORDER BY grade, sub_grade;

----------------------------------------------------------------------------------------------------------------------------------
##...3...Total Payment: Verified vs Non-Verified

SELECT 
    verification_status,
    SUM(loan_amnt) AS total_loan_amount
FROM public
GROUP BY verification_status;

-----------------------------------------------------------------------------------------------------------------------------------
##..4...State-wise & Last Credit Pull Date Loan Status

SELECT 
    addr_state,
    loan_status,
    COUNT(id) AS total_loans
FROM public
GROUP BY addr_state, loan_status
ORDER BY addr_state;
-----------------------------------------------------------------------------------------------------------------------------------------
##...5..Home Ownership vs Last Payment Date Stats
SELECT 
    home_ownership,
    COUNT(id) AS total_loans
FROM public
GROUP BY home_ownership
ORDER BY total_loans DESC;